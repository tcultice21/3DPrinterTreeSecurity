#ifndef __PHOTON_H__
#define __PHOTON_H__
#include "stdint.h"

void photon128(uint8_t *message, const int32_t message_bytes, uint8_t *hash);

#endif //__PHOTON_H__
